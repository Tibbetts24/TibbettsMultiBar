# TibbettsMultiBar

TibbettsMultiBar is a lightweight, cross-version replacement for the default XP and Reputation bars.

## Highlights
- Texture & font selection with live preview + search
- Tick presets (None / 10% / 20%) with optional hover tooltips
- Blizzard-style color pickers with opacity
- Works on Retail, Classic Era, TBC Anniversary, and Wrath

## Commands
- /tmb
- /tibbettsmultibar
